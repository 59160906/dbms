
@extends('layouts.app')

@section('content')
<div class="container">
   <div class="row">
       <div class="col-md-8 col-md-offset-2">
           <div class="panel panel-default">

               <div class="panel-heading">
               <form method="post" action="{{ route('transfer.store') }}">
                   {{ csrf_field() }}
                   <div class="form-group">
                       <label for="ACC_No_Source">หมายเลขบัญชีต้นทาง</label>
                       <td>
                       <select name = "ACC_No_Source">
                       @foreach($account as $row)
                           <option>{{ $row->ACC_NO }}</option>
                       @endforeach
                       </select>
                       </td>
                   </div>
                   <div class="form-group">
                       <label for="ACC_No_Dest">หมายเลขบัญชีปลายทาง</label>
                       <td>
                       <select name = "ACC_No_Dest">
                       @foreach($account as $row)
                           <option>{{ $row->ACC_NO }}</option>
                       @endforeach
                       </select>
                       </td>
                   </div>
                   <div class="form-group">
                       <label for="Amount">จำนวนเงิน</label>
                       <input type="text" name="Amount" class="form-control">

                   <div>
                       <button type="submit" class="btn btn-default">โอนเงิน</button>
                   </div>
               </form>

               </div>
           </div>
       </div>
   </div>
</div>
@endsection

