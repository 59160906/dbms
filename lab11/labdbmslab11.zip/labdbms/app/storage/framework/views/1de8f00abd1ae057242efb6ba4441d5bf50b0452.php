<?php /* /app/resources/views/account/Transfer.blade.php */ ?>



<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row">
       <div class="col-md-8 col-md-offset-2">
           <div class="panel panel-default">

               <div class="panel-heading">
               <form method="post" action="<?php echo e(route('transfer.store')); ?>">
                   <?php echo e(csrf_field()); ?>

                   <div class="form-group">
                       <label for="ACC_No_Source">หมายเลขบัญชี</label>
                       <input type="text" name="ACC_No_Source" class="form-control">
                   </div>
                   <div class="form-group">
                       <label for="ACC_No_Dest">หมายเลขบัญชีปลายทาง</label>
                       <input type="text" name="ACC_No_Dest" class="form-control">
                   </div>
                   <div class="form-group">
                       <label for="Amount">จำนวนเงิน</label>
                       <input type="text" name="Amount" class="form-control">

                   <div>
                       <button type="submit" class="btn-default">โอนเงิน</button>
                   </div>
               </form>

               </div>
           </div>
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>