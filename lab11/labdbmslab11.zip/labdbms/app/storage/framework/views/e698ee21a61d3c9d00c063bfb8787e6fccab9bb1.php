<?php /* /app/resources/views/account/index.blade.php */ ?>


<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row">
       <div class="col-md-8 col-md-offset-2">
           <div class="panel panel-default">
           <div>
             <a href="<?php echo e(route('account.create')); ?>" class="btn btn-success">เปิดบัญชี</a>
             <a href="<?php echo e(route('transfer.create')); ?>" class="btn btn-success">โอนเงิน</a>
           </div>
               <div class="panel-heading">
               <table class="table table-sm table-dark">
 <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">ACC_NO</th>
      <th scope="col">ACC_NAME</th>
      <th scope="col">ACC_Surname</th>
      <th scope="col">Balance</th>
    </tr>
  </thead>
  <?php $i=1; ?>
  <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
   <tr>
     <th scope="row"><?php echo $i++ ?></th>
     <td><?php echo e($row->ACC_NO); ?></td>
     <td><?php echo e($row->ACC_NAME); ?></td>
     <td><?php echo e($row->ACC_Surname); ?></td>
     <td><?php echo e($row->Balance); ?></td>
     <td><a href="<?php echo e(route('account.edit',$row->id)); ?>" class="btn btn-warning">Edit</a></td>
     <td><form action="<?php echo e(route('account.destroy',$row->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field("Delete"); ?>
          
            <button class="btn btn-danger">Delete</button>
          </form>
          </td>
   </tr>
  </tbody>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>