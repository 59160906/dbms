<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use App\Transfer;
use App\Account;

class TransferController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $account = Account::all();
        return view('account.transfer',compact('account'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $transfer = new Transfer;
 
        $request->validate([
            'ACC_No_Source' => 'required:max:10',
            'ACC_No_Dest' => 'required:max:10',
            'Amount' => 'required'
        ]);

        $acc = DB::select("Select * from Account where ACC_NO=?",[$request->ACC_No_Source]);
        
        foreach($acc as $row) {

        }
        if  ($row->Balance > $request->Amount) {
            DB::beginTransaction();
            $transfer->ACC_No_Source = $request->ACC_No_Source;
            $transfer->ACC_No_Dest = $request->ACC_No_Dest;
            $transfer->DateOp = date("Y-m-d H:i:s");
            $transfer->Amount = $request->Amount;
            $savetran = $transfer->save();
 
            $saveaccsrc = DB::update("update Account set Balance=Balance- ? where ACC_NO = ?",[$transfer->Amount,$transfer->ACC_No_Source]);
 
            $saveaccdest = DB::update("update Account set Balance=Balance+ ? where ACC_NO = ?",[$transfer->Amount,$transfer->ACC_No_Dest]);
 
            if ($savetran && $saveaccsrc && $saveaccdest){
                DB::commit();
            }else{
                DB::rollback();
            }
        }
        return redirect('account');
 
    }
 
 

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
