<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transfer extends Model
{
    protected $table = "transfer";

    protected $fillable =[
        'ACC_No_Source','ACC_No_Dest','DateOp','Amount'
    ];
 
}
